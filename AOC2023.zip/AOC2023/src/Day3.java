import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Day3 {
    ArrayList<ArrayList<Character>> map = new ArrayList<>();
    HashMap<Integer,Integer> gears = new HashMap<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        int total = 0;
        while(true){
            String str = s.nextLine();
            ArrayList<Character> z = new ArrayList<>();
            if (str.equals("t")){
                break;
            }
            map.add(z);
            for (int i = 0; i < str.length(); i++) {
                z.add(str.charAt(i));
            }
        }
        for (int i = 0; i < map.size(); i++) {
            int rTotal = 0;
            int numIn = 0;
            for (int j = 0; j < map.get(i).size(); j++) {
                if (map.get(i).get(j) >= '0' && map.get(i).get(j) <= '9'){
                    rTotal*=10;
                    rTotal += map.get(i).get(j)-'0';
                    numIn++;
                }
                else{
                    if (numIn > 0) {
                        if (j < map.get(i).size() && map.get(i).get(j) == '*'){
                            total += doGear(i*map.get(i).size()+j,rTotal);
                        }
                        if (j -1- numIn >= 0 && map.get(i).get(j -1- numIn) != '.'){
                            total += doGear((i)*map.get(i).size()+(j-1-numIn),rTotal);
                        }
                        for (int k = -1; k < 2; k+=2) {
                            for (int l = j - 1 - numIn; l <= j; l++) {
                                if (l >= 0 && l < map.get(i).size() && i +k >= 0 && i +k < map.size() && map.get(i +k).get(l) != '.'){
                                    total += doGear((i+k)*map.get(i+k).size()+(l),rTotal);
                                }
                            }
                        }
                        rTotal = 0;
                        numIn = 0;
                    }
                }
            }
            if (numIn > 0){
                if (map.get(i).size() < map.get(i).size() && map.get(i).get(map.get(i).size()) == '*'){
                    total += doGear(i*map.get(i).size()+map.get(i).size(),rTotal);
                }
                if (map.get(i).size() -1- numIn >= 0 && map.get(i).get(map.get(i).size() -1- numIn) != '.'){
                    total += doGear((i)*map.get(i).size()+(map.get(i).size()-1-numIn),rTotal);
                }
                for (int k = -1; k < 2; k+=2) {
                    for (int l = map.get(i).size() - 1 - numIn; l <= map.get(i).size(); l++) {
                        if (l >= 0 && l < map.get(i).size() && i +k >= 0 && i +k < map.size() && map.get(i +k).get(l) != '.'){
                            total += doGear((i)*map.get(i+k).size()+(l),rTotal);
                        }
                    }
                }
            }
        }
        System.out.println(total);
    }

    int doGear(int gear, int rTotal){
        if (gears.get(gear) == null){
            gears.put(gear,rTotal);
            return 0;
        }
        return gears.get(gear)*rTotal;
    }

}

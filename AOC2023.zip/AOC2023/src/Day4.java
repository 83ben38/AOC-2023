import java.util.ArrayList;
import java.util.Scanner;

public class Day4 {
    ArrayList<Integer> copies = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        int total = 219;
        int num = 0;
        for (int i = 0; i < 219; i++) {
            copies.add(1);
        }
        while(true){
            int rTotal = 1;
            if (s.next().equals("t")){
                break;
            }
            s.next();
            ArrayList<Integer> winningNumbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                winningNumbers.add(s.nextInt());
            }
            s.next();
            for (int i = 0; i < 25; i++) {
                if (winningNumbers.contains(s.nextInt())){
                    total+=copies.get(num);
                    copies.set(rTotal+num,copies.get(rTotal+num)+copies.get(num));
                    rTotal++;
                }

            }
            num++;
        }
        System.out.println(total);
    }
}

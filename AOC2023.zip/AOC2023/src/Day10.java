import java.util.ArrayList;
import java.util.Scanner;

public class Day10 {
    public static int maxNum = 1;
    ArrayList<ArrayList<pipe>> pipes = new ArrayList<>();
    ArrayList<ArrayList<pipe>> pipes2 = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        int[] coords = new int[2];
        while (s.hasNextLine()){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            pipes.add(new ArrayList<>());
            for (int i = 0; i < str.length(); i++) {
                pipe p = new pipe(str.charAt(i));
                if (str.charAt(i) == 'S'){
                    coords[0] = pipes.size()-1;
                    coords[1] = i;
                }
                pipes.getLast().add(p);
                if (pipes.size()>1){
                    p.up = pipes.get(pipes.size()-2).get(i);
                    p.up.down = p;
                }
                if (pipes.getLast().size()>1){
                    p.left = pipes.getLast().get(i-1);
                    p.left.right = p;
                }
            }
        }
        pipe p1 = null;
        pipe p2 = null;
        String dir1 = null;
        String dir2 = null;
        boolean done = false;
        if (pipes.get(coords[0]).get(coords[1]+1).getNext("r") != null){
            p1 = pipes.get(coords[0]).get(coords[1]+1);
            done =true;
            dir1 = "r";
        }
        if (pipes.get(coords[0]).get(coords[1]-1).getNext("l") != null){
            if (!done) {
                p1 = pipes.get(coords[0]).get(coords[1] - 1);
                done = true;
                dir1 = "l";
            }
            else{
                p2 = pipes.get(coords[0]).get(coords[1] - 1);
                dir2 = "l";
            }
        }
        if (pipes.get(coords[0]-1).get(coords[1]).getNext("u") != null){
            if (!done) {
                p1 = pipes.get(coords[0]-1).get(coords[1]);
                done = true;
                dir1 = "u";
            }
            else{
                p2 = pipes.get(coords[0]-1).get(coords[1]);
                dir2 = "u";
            }
        }
        if (pipes.get(coords[0]+1).get(coords[1]).getNext("d") != null){
            if (!done) {
                p1 = pipes.get(coords[0]+1).get(coords[1]);
                done = true;
                dir1 = "d";
            }
            else{
                p2 = pipes.get(coords[0]+1).get(coords[1]);
                dir2 = "d";
            }
        }
        pipes.get(coords[0]).get(coords[1]).loop = true;
        pipes.get(coords[0]).get(coords[1]).pipeType = switch (dir1){
            case "u"->switch (dir2){
                case "d"->'|';
                case "r" -> 'L';
                default -> 'J';
            };
            case "d"->switch (dir2){
                case "u"->'|';
                case "r" -> 'F';
                default -> '7';
            };
            case "r"->switch (dir2){
                case "d"->'F';
                case "l" -> '-';
                default -> 'L';
            };
            default->switch (dir2){
                case "d"->'7';
                case "r" -> '-';
                default -> 'J';
            };
        };
        int count = 0;
        while(p1!=p2){
            p1.loop = true;
            p2.loop = true;
            dir1 = p1.getNext(dir1);
            p1 = dir1 =="u" ? p1.up : dir1 =="l" ? p1.left :dir1 =="r" ? p1.right :p1.down;
            dir2 = p2.getNext(dir2);
            p2 = dir2 =="u" ? p2.up : dir2 =="l" ? p2.left :dir2 =="r" ? p2.right :p2.down;
        }
        p1.loop = true;
        for (ArrayList<pipe> p: pipes) {
            for (pipe d: p) {
                if (!d.loop){
                    d.pipeType = '.';
                }
            }
        }
        for (int i = 0; i < pipes.size(); i++) {
            pipes2.add(new ArrayList<>());
            pipes2.add(new ArrayList<>());
            pipes2.add(new ArrayList<>());
            for (int j = 0; j < pipes.get(i).size(); j++) {
                char pipeType = pipes.get(i).get(j).pipeType;
                if (pipeType == '.'){
                    for (int k = 0; k < 3; k++) {
                        pipes2.get(pipes2.size()-1).add(new pipe('.'));
                        pipes2.get(pipes2.size()-2).add(new pipe('.'));
                        pipes2.get(pipes2.size()-3).add(new pipe('.'));
                    }
                }
                else{
                    pipes2.get(pipes2.size()-1).add(new pipe('.'));
                    if (pipeType == '|' || pipeType == 'F' || pipeType == '7'){
                        pipes2.get(pipes2.size()-1).add(new pipe('|'));
                    }
                    else{
                        pipes2.get(pipes2.size()-1).add(new pipe('.'));
                    }
                    pipes2.get(pipes2.size()-1).add(new pipe('.'));
                    if (pipeType == '-' || pipeType == 'J' || pipeType == '7'){
                        pipes2.get(pipes2.size()-2).add(new pipe('-'));
                    }
                    else{
                        pipes2.get(pipes2.size()-2).add(new pipe('.'));
                    }
                    pipes2.get(pipes2.size()-2).add(new pipe(pipeType));
                    if (pipeType == '-' || pipeType == 'F' || pipeType == 'L'){
                        pipes2.get(pipes2.size()-2).add(new pipe('-'));
                    }
                    else{
                        pipes2.get(pipes2.size()-2).add(new pipe('.'));
                    }
                    pipes2.get(pipes2.size()-3).add(new pipe('.'));
                    if (pipeType == '|' || pipeType == 'J' || pipeType == 'L'){
                        pipes2.get(pipes2.size()-3).add(new pipe('|'));
                    }
                    else{
                        pipes2.get(pipes2.size()-3).add(new pipe('.'));
                    }
                    pipes2.get(pipes2.size()-3).add(new pipe('.'));
                }
            }
        }
        for (int i = 1; i < pipes2.size(); i++) {
            for (int j = 1; j < pipes2.get(i).size(); j++) {
                pipe p =pipes2.get(i).get(j);
                p.up =pipes2.get(i-1).get(j);
                p.up.down = p;
                p.left = pipes2.get(i).get(j-1);
                p.left.right = p;
            }
        }
            for (int i = 0; i < pipes2.size(); i++) {
                if (i == 0 || i == pipes2.size()-1) {
                    for (int j = 0; j < pipes2.get(i).size(); j++) {
                        pipes2.get(i).get(j).checkInLoop(0);
                    }
                }
                else{
                    for (int j = 0; j < pipes2.get(i).size(); j+=pipes2.get(i).size()-1) {
                        pipes2.get(i).get(j).checkInLoop(0);
                    }
                }
            }
        for (int i = 1; i < 10000; i++) {
            maxNum = i+1;
            for (ArrayList<pipe> p : pipes2) {
                for (pipe d: p) {
                    if (d.distance == i){
                        d.checkInLoop(d.distance);
                    }
                }
            }
        }



        for (int i = 1; i < pipes2.size(); i++) {
            System.out.println();
            for (int j = 1; j < pipes2.get(i).size(); j++) {
                if (pipes2.get(i).get(j).pipeType == '.'){
                    if (pipes2.get(i).get(j).distance==-1){
                        count++;
                    }
                    System.out.print(pipes2.get(i).get(j).distance==-1?'I':'O');
                }
                else{
                    System.out.print(pipes2.get(i).get(j).pipeType);
                }
            }
        }
        System.out.println();
        System.out.println(count);
    }
    public class pipe{
        pipe up;
        pipe down;
        pipe right;
        pipe left;
        char pipeType;
        boolean loop = false;
        int distance = -1;
        public pipe(char type){
            pipeType = type;
        }
        public String getNext(String cameFrom){
            if (pipeType == '-') {
                if (cameFrom == "u" || cameFrom == "d"){
                    return null;
                }
                return cameFrom == "r" ? "r" : "l";
            }
            if (pipeType == '|'){
                if (cameFrom == "l" || cameFrom == "r"){
                    return null;
                }
                return cameFrom == "u" ? "u" : "d";
            }
            if (pipeType == 'L'){
                if (cameFrom == "u" || cameFrom == "r"){
                    return null;
                }
                return cameFrom == "d" ? "r" : "u";
            }
            if (pipeType == '7'){
                if (cameFrom == "d" || cameFrom == "l"){
                    return null;
                }
                return cameFrom == "r" ? "d" : "l";
            }
            if (pipeType == 'F'){
                if (cameFrom == "r" || cameFrom == "d"){
                    return null;
                }
                return cameFrom == "u" ? "r" : "d";
            }
            if (pipeType == 'J'){
                if (cameFrom == "u" || cameFrom == "l"){
                    return null;
                }
                return cameFrom == "d" ? "l" : "u";
            }
            return null;
        }
        public void checkInLoop(int dist){
            if(pipeType !='.'){
                return;

            }
            if (dist > maxNum){return;}
            if((distance < dist && distance!=-1)){
                return;
            }
            distance = dist;
            if (up!=null){
                up.checkInLoop(dist+1);
            }if (down!=null){
                down.checkInLoop(dist+1);
            }if (left!=null){
                left.checkInLoop(dist+1);
            }if (right!=null){
                right.checkInLoop(dist+1);
            }
        }
    }
}

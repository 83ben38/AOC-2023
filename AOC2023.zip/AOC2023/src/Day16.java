import java.util.ArrayList;
import java.util.Scanner;

public class Day16 {
    ArrayList<ArrayList<tile>> tiles = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            tiles.add(new ArrayList<>());
            for (int i = 0; i < str.length(); i++) {
                tiles.getLast().add(new tile(str.charAt(i)));
            }
        }
        int maxEnergized =0;
        for (int i = 0; i < tiles.get(0).size(); i++) {
            int energized = getEnergized(0,i,1);
            if (energized > maxEnergized){
                maxEnergized = energized;
            }
            energized = getEnergized(tiles.size()-1,i,3);
            if (energized > maxEnergized){
                maxEnergized = energized;
            }
        }
        for (int i = 0; i < tiles.size(); i++) {
            int energized = getEnergized(i,0,0);
            if (energized > maxEnergized){
                maxEnergized = energized;
            }
            energized = getEnergized(i,tiles.get(0).size()-1,2);
            if (energized > maxEnergized){
                maxEnergized = energized;
            }
        }
        System.out.println(maxEnergized);
    }
    public int getEnergized (int x, int y, int direction){
        for (int i = 0; i < tiles.size(); i++) {
            for (int j = 0; j < tiles.get(i).size(); j++) {
                tiles.get(i).get(j).energized = false;
                tiles.get(i).get(j).directionsEnergized= new boolean[]{false,false,false,false};
            }
        }
        tiles.get(x).get(y).shootLaser(x,y,direction);
        int energized = 0;
        for (int i = 0; i < tiles.size(); i++) {
            for (int j = 0; j < tiles.get(i).size(); j++) {
                if (tiles.get(i).get(j).energized) {
                    energized++;
                }
            }
        }
        return energized;
    }
    public class tile{
        char mirrorType;
        boolean energized = false;
        boolean[] directionsEnergized = new boolean[]{false,false,false,false};
        public tile(char mirrorType){
            this.mirrorType =mirrorType;
        }
        public void shootLaser(int x, int y, int direction){
            energized = true;
            if (directionsEnergized[direction]){
                return;
            }
            directionsEnergized[direction] = true;
            if (mirrorType == '.' || ((direction== 0 || direction==2)&&mirrorType=='-')|| ((direction== 1 || direction==3)&&mirrorType=='|')){
                switch(direction){
                    case 0 -> y++;
                    case 1 -> x++;
                    case 2 -> y--;
                    case 3 -> x--;
                }
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,direction);
                }
            }
            else if (mirrorType == '/'){
                switch(direction){
                    case 0 -> x--;
                    case 1 -> y--;
                    case 2 -> x++;
                    case 3 -> y++;
                }
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,switch (direction){
                        case 0 -> 3;
                        case 1 -> 2;
                        case 2 -> 1;
                        default -> 0;
                    });
                }
            }
            else if (mirrorType == '\\'){
                switch(direction){
                    case 0 -> x++;
                    case 1 -> y++;
                    case 2 -> x--;
                    case 3 -> y--;
                }
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,switch (direction){
                        case 0 -> 1;
                        case 2 -> 3;
                        case 3 -> 2;
                        default -> 0;
                    });
                }
            }
            else if (mirrorType == '-'){
                y++;
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,0);
                }
                y-=2;
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,2);
                }
            }
            else if (mirrorType == '|'){
                x++;
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,1);
                }
                x-=2;
                if (tiles.size() > x &&x >= 0 && tiles.get(0).size() > y && y>= 0){
                    tiles.get(x).get(y).shootLaser(x,y,3);
                }
            }
        }
    }
}

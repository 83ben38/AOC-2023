import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Day7 {
    ArrayList<Hand> hands = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (s.hasNext()){
            String hand = s.next();
            if (hand.equals("t")){
                break;
            }
            hands.add(new Hand(hand,s.nextInt()));
        }
        hands.sort(Hand::compare);
        int total = 0;
        for (int i = 1; i <= hands.size(); i++) {
            total += i * hands.get(i-1).bid;
        }
        System.out.println(total);
    }
    public class Hand{
        int bid;
        int rank;
        ArrayList<Character> cards = new ArrayList<>();
        public Hand(String z, int bid){
            z = z.replaceAll("T",(char)('9'+1) + "").replaceAll("J",(char)('0'-1) + "").replaceAll("Q",(char)('9'+3) + "").replaceAll("K",(char)('9'+4) + "").replaceAll("A",(char)('9'+5) + "");
            this.bid=bid;
            for (int i = 0; i < 5; i++) {
                cards.add(z.charAt(i));
            }
            rank = rank();
        }
        public int rank(){
            int matches = 0;
            int max = 0;
            char maxChar = '/';
            HashMap<Character,Integer> numChars = new HashMap<Character, Integer>();
            for (int i = 0; i < cards.size(); i++) {
                if (cards.get(i) != '0'-1) {
                    numChars.put(cards.get(i), numChars.getOrDefault(cards.get(i), 0) + 1);
                    if (numChars.get(cards.get(i)) > max) {
                        max = numChars.get(cards.get(i));
                        maxChar = cards.get(i);
                    }
                }
            }

            for (int i = 0; i < cards.size(); i++) {
                for (int j = i+1; j < cards.size(); j++) {
                    char z1 = cards.get(i);
                    char z2 = cards.get(j);
                    if (z1=='0'-1){
                        z1 = maxChar;
                    }
                    if (z2=='0'-1){
                        z2 = maxChar;
                    }
                    if (z1 == z2){
                        matches++;
                    }
                }
            }
            if (matches == 10){
                return 1;
            }
            if (matches == 6){
                return 2;
            }
            return 7 - matches;
        }
        public int compare(Hand z){
            if (z.rank > rank){
                return 1;
            }
            if (rank > z.rank){
                return -1;
            }
            for (int i = 0; i < cards.size(); i++) {
                if (cards.get(i) > z.cards.get(i)){
                    return 1;
                }
                if (z.cards.get(i) > cards.get(i)){
                    return -1;
                }
            }
            return 0;
        }

    }
}

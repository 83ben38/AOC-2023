import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Day8 {
    public static int insructionLength;
    public HashMap<String,node> map = new HashMap<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        String instructions = s.next();
        while (s.hasNext()){
            String v = s.next();
            if (v.length()<3){
                break;
            }
            s.next();
            getOrCreate(v).left=getOrCreate(s.next().substring(1,4));
            getOrCreate(v).right=getOrCreate(s.next().substring(0,3));
        }
        insructionLength = instructions.length();
        ArrayList<path> current = new ArrayList<>();
        for (node n: map.values()) {
            if (n.name.endsWith("A")) {
                current.add(new path());
                current.getLast().add(n);
            }
        }
        boolean breakOut = true;
        while (breakOut){
            for (int i = 0; i < instructions.length(); i++) {
                boolean breakOutReal = true;
                for (path n: current) {
                    if (!n.complete){
                        breakOutReal = false;
                        node z = n.beenTo.getLast();
                        if (instructions.charAt(i)=='L'){
                            n.add(z.left);
                        }
                        else {
                            n.add(z.right);
                        }
                    }
                }
                breakOut = !breakOutReal;
            }
        }
        int total = 0;
        int[] nums = new int[current.size()];
        for (int i = 0; i < current.size(); i++) {
            nums[i] = current.get(i).num+current.get(i).offset-1;
        }
        while (true){
            boolean same = true;
            int min = nums[0];
            int minNum = 1;
            for (int i = 1; i < current.size(); i++) {
                if (nums[i] < min){
                    min = nums[i];
                    minNum = i;
                    same = false;
                }
                if (nums[i] > min){
                    same = false;
                }
            }
            if (same){
                System.out.println(min);
                return;
            }
            nums[minNum] += current.get(minNum).num;
        }
    }
    public node getOrCreate(String z){
        if (map.get(z)==null){
            map.put(z,new node(z));
        }
        return map.get(z);
    }
    public class path{
        ArrayList<node> beenTo = new ArrayList<>();
        int num;
        int offset;
        boolean complete;
        public void add(node n){
            beenTo.add(n);
            if(n.name.endsWith("Z")){
                num = beenTo.size()-1;
                complete = true;
            }
        }
    }

    public class node{
        public node right;
        public node left;
        public String name;
        public node(String name){
            this.name=name;
        }
    }
}

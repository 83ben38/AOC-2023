import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Day12 {
    public static HashMap<String, Long> possibilites  = new HashMap<>();

    public void start(){
        Scanner s = new Scanner(System.in);
        long total = 0;
        while (true){
            possibilites = new HashMap<>();
            String str = s.next();
            if (str.equals("t")){
                break;
            }
            line l = new line();
            for (int j = 0; j < 5; j++) {
                for (int i = 0; i < str.length(); i++) {
                    l.commands.add(str.charAt(i)=='#' ? 1 : str.charAt(i)=='.' ? 0 : 2);
                }
                if (j != 4) {
                    l.commands.add(2);
                }
            }
            l.commands.add(0);
            str = s.next();
            for (int i = 0; i < 5; i++) {
                Scanner sc = new Scanner(str.replaceAll(","," "));
                while(sc.hasNextInt()){
                    l.requiredDamaged.add(sc.nextInt());
                }
            }
            long d = l.checkPossibilities();
            System.out.println(d +" ");
            total += d;
        }
        System.out.println(total);
    }

    public class line{
        ArrayList<Integer> commands = new ArrayList<>();
        ArrayList<Integer> requiredDamaged = new ArrayList<>();
        int currentNum = 0;
        String str;

        public boolean isRequired(){

            int damageCompleted = 0;
            for (int i = 0; i < commands.size(); i++) {
                if (commands.get(i) == 0){
                    if (currentNum> 0){
                        if (damageCompleted >= requiredDamaged.size()){
                            return false;
                        }
                        if (requiredDamaged.get(damageCompleted)==currentNum){
                            currentNum = 0;
                            damageCompleted++;
                        }
                        else{
                            return false;
                        }
                    }
                }
                if (commands.get(i)==1){
                    currentNum++;
                }
            }
            return damageCompleted == requiredDamaged.size();
        }
        public long checkPossibilities(){

            if (possibilites.containsKey(str())){
                return possibilites.get(str());
            }
            if (commands.contains(2)){
                while (commands.get(0) != 2){
                    if (commands.get(0) == 0){
                        if (currentNum> 0){
                            if (requiredDamaged.isEmpty()){
                                possibilites.put(str(),0L);
                                return 0;
                            }
                            if (requiredDamaged.get(0)==currentNum){
                                currentNum = 0;
                                requiredDamaged.remove(0);
                            }
                            else{
                                possibilites.put(str(),0L);
                                return 0;
                            }
                        }

                    }
                    else{
                        currentNum++;
                        if(requiredDamaged.isEmpty()){
                            possibilites.put(str(),0L);
                            return 0;
                        }
                        if(currentNum > requiredDamaged.get(0))
                        {
                            possibilites.put(str(),0L);
                            return 0;
                        }
                    }
                    commands.remove(0);
                }

                line l1 = new line();
                l1.commands = new ArrayList<>(commands);
                l1.requiredDamaged = new ArrayList<>(requiredDamaged);
                l1.commands.set(commands.indexOf(2),0);
                l1.currentNum = currentNum;
                line l2 = new line();
                l2.commands = new ArrayList<>(commands);
                l2.requiredDamaged = new ArrayList<>(requiredDamaged);
                l2.commands.set(commands.indexOf(2),1);
                l2.currentNum = currentNum;
                long num = l1.checkPossibilities()+l2.checkPossibilities();
                possibilites.put(str(),num);
                return num;
            }
            return isRequired() ? 1 : 0;
        }


        public String str() {
            if (str == null){
                str = currentNum + ","+ Arrays.toString(commands.toArray()) + ","+ Arrays.toString(requiredDamaged.toArray());
            }
            return str;

        }
    }

}

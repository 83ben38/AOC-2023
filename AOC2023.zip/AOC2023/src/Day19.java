import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class Day19 {
    public class condition {
        String workflowOutput;
        int num;
        boolean operation;
        char variable;
        public part[] getAccepted(part p){
            int zMin = switch (variable){
                case 'x' -> p.minX;
                case 'm' -> p.minM;
                case 's' -> p.minS;
                default -> p.minA;
            };
            int zMax = switch (variable){
                case 'x' -> p.maxX;
                case 'm' -> p.maxM;
                case 's' -> p.maxS;
                default -> p.maxA;
            };
            if (operation){
                if (zMin > num){
                    return new part[]{p, null};
                }
                if(zMax <= num){
                    return new part[]{null,p};
                }
                part p1 = new part(p);
                part p2 = new part(p);
                switch (variable){
                    case 'x' -> {
                        p1.minX =num+1;
                        p2.maxX = num;
                    }
                    case 'm' -> {
                        p1.minM =num+1;
                        p2.maxM = num;
                    }
                    case 's' -> {
                        p1.minS =num+1;
                        p2.maxS = num;
                    }
                    default -> {
                        p1.minA =num+1;
                        p2.maxA = num;
                    }
                };
                return new part[]{p1,p2};
            }
            if (zMax < num){
                return new part[]{p, null};
            }
            if(zMin >= num){
                return new part[]{null,p};
            }
            part p1 = new part(p);
            part p2 = new part(p);
            switch (variable){
                case 'x' -> {
                    p1.maxX =num-1;
                    p2.minX = num;
                }
                case 'm' -> {
                    p1.maxM =num-1;
                    p2.minM = num;
                }
                case 's' -> {
                    p1.maxS =num-1;
                    p2.minS = num;
                }
                default -> {
                    p1.maxA =num-1;
                    p2.minA = num;
                }
            };
            return new part[]{p1,p2};
        }
    }
    public class part{
        int minX;
        int maxX;
        int minM;
        int maxM;
        int minA;
        int maxA;
        int minS;
        int maxS;
        public part(){}
        public part(part p){
            this.minA = p.minA;
            this.maxA = p.maxA;
            this.maxS = p.maxS;
            this.maxM = p.maxM;
            this.maxX = p.maxX;
            this.minS = p.minS;
            this.minM = p.minM;
            this.minX = p.minX;
        }
    }
    public class workflow{
        ArrayList<condition> conditions = new ArrayList<>();
        workflow defaultWorkflow;
        String name;
        public workflow(String name){
            this.name = name;
        }
        public long numAccepted(part p){
            if (name.equals("A")){
                return (long) (1+p.maxA - p.minA) *(1+p.maxM-p.minM)*(1+p.maxS-p.minS)*(1+p.maxX-p.minX);
            }
            if(name.equals("R")){
                return 0;
            }
            long total = 0;
            for (int i = 0; i < conditions.size(); i++) {
                part[] parts = conditions.get(i).getAccepted(p);
                if (parts[0] != null){
                    total += getOrCreateWorkflow(conditions.get(i).workflowOutput).numAccepted(parts[0]);
                }
                p = parts[1];
                if (p == null){
                    break;
                }

            }
            if (p != null){
                total += defaultWorkflow.numAccepted(p);
            }
            return total;
        }
    }
    HashMap<String,workflow> workflows = new HashMap<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.isEmpty()){
                break;
            }
            workflow w = getOrCreateWorkflow(str.substring(0,str.indexOf("{")));
            str = str.substring(str.indexOf("{")+1);
            while (str.contains(",")){
                String st = str.substring(0,str.indexOf(","));
                str = str.substring(str.indexOf(",")+1);
                condition c = new condition();
                w.conditions.add(c);
                c.variable = st.charAt(0);
                c.operation = st.charAt(1) == '>';
                c.num = Integer.parseInt(st.substring(2,st.indexOf(":")));
                c.workflowOutput = st.substring(st.indexOf(":")+1);
            }
            w.defaultWorkflow = getOrCreateWorkflow(str.substring(0,str.length()-1));
        }
        part p = new part();
        p.minA = 1;
        p.maxA = 4000;
        p.minX = 1;
        p.maxX = 4000;
        p.minM = 1;
        p.maxM = 4000;
        p.minS = 1;
        p.maxS = 4000;
        System.out.println(getOrCreateWorkflow("in").numAccepted(p));
    }
    public workflow getOrCreateWorkflow(String s){
        if (!workflows.containsKey(s)){
            workflows.put(s,new workflow(s));
        }
        return workflows.get(s);
    }
    /*
    HashMap<String,workflow> workflows = new HashMap<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.isEmpty()){
                break;
            }
            workflow w = getOrCreateWorkflow(str.substring(0,str.indexOf("{")));
            str = str.substring(str.indexOf("{")+1);
            while (str.contains(",")){
                String st = str.substring(0,str.indexOf(","));
                str = str.substring(str.indexOf(",")+1);
                condition c = new condition();
                w.conditions.add(c);
                c.variable = st.charAt(0);
                c.operation = st.charAt(1) == '>';
                c.num = Integer.parseInt(st.substring(2,st.indexOf(":")));
                c.workflowOutput = st.substring(st.indexOf(":")+1);
            }
            w.defaultWorkflow = getOrCreateWorkflow(str.substring(0,str.length()-1));
        }
        long total = 0;
        while (true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            part p = new part();
            p.x = Integer.parseInt(str.substring(3,str.indexOf(",")));
            str = str.substring(str.indexOf(",")+1);
            p.m = Integer.parseInt(str.substring(2,str.indexOf(",")));
            str = str.substring(str.indexOf(",")+1);
            p.a = Integer.parseInt(str.substring(2,str.indexOf(",")));
            str = str.substring(str.indexOf(",")+1);
            p.s = Integer.parseInt(str.substring(2,str.length()-1));
            if (getOrCreateWorkflow("in").getWorkFlow(p).name.equals("A")){
                total += p.x + p.m + p.a + p.s;
            }
        }
        System.out.println(total);
    }
    public workflow getOrCreateWorkflow(String s){
        if (!workflows.containsKey(s)){
            workflows.put(s,new workflow(s));
        }
        return workflows.get(s);
    }
    public class part{
        int x;
        int m;
        int a;
        int s;
    }
    public class workflow{
        ArrayList<condition> conditions = new ArrayList<>();
        workflow defaultWorkflow;
        String name;
        public workflow(String name){
            this.name = name;
        }
        public workflow getWorkFlow(part p){
            if (conditions.size() < 1){
                return this;
            }
            for (int i = 0; i < conditions.size(); i++) {
                if (conditions.get(i).meetsCondition(p)){
                    return workflows.get(conditions.get(i).workflowOutput).getWorkFlow(p);
                }
            }
            return defaultWorkflow.getWorkFlow(p);
        }
    }
    public class condition{
        String workflowOutput;
        int num;
        boolean operation;
        char variable;
        public boolean meetsCondition(part p){
            if (operation){
                int z = switch (variable){
                    case 'x' -> p.x;
                    case 'm' -> p.m;
                    case 's' -> p.s;
                    default -> p.a;
                };
                return z > num;
            }
            else{
                int z = switch (variable){
                    case 'x' -> p.x;
                    case 'm' -> p.m;
                    case 's' -> p.s;
                    default -> p.a;
                };
                return z < num;
            }
        }
    }

     */
}

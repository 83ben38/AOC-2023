import java.util.Scanner;

public class Day1 {
    String[] nums = new String[]{"one","two","three","four","five","six","seven","eight","nine"};
    public void start(){
        Scanner s = new Scanner(System.in);
        int total = 0;
        while (s.hasNextLine()){
            String v = s.nextLine();
            if (v.equals("t")){
                break;
            }
            int lastInt = -1;
            int firstInt = -1;
            for (int i = 0; i < v.length(); i++) {
                for (int j = 0; j < nums.length; j++) {
                    if (nums[j].length() + i > v.length()){
                        continue;
                    }
                    if (v.substring(i,i+nums[j].length()).equals(nums[j])){
                        if (firstInt==-1){
                            firstInt = j+1;
                        }
                        lastInt = j+1;
                    }
                }
                if (v.charAt(i) >= '0' && v.charAt(i) <= '9'){
                    if (firstInt==-1){
                        firstInt = (int)(v.charAt(i) - '0');
                    }
                    lastInt = (int)(v.charAt(i) - '0');
                }
            }
            total += lastInt;
            total += firstInt*10;
        }
        System.out.println(total);
    }
}

import java.util.ArrayList;
import java.util.Scanner;

public class Day9 {
    public ArrayList<sequence> sequences = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (s.hasNextLine()){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            sequence q = new sequence();
            sequences.add(q);
            Scanner z = new Scanner(str);
            while (z.hasNextInt()){
                q.add(z.nextInt());
            }
        }
        int total = 0;
        for (int i = 0; i < sequences.size(); i++) {
            total += sequences.get(i).extrapolate();
        }
        System.out.println(total);
    }

    public class sequence{
        public ArrayList<Integer> nums = new ArrayList<>();
        public sequence subSequence;
        public void add(int num){
            nums.add(num);
        }
        public int extrapolate(){
            for (int i = 0; i <= nums.size(); i++) {
                if(i == nums.size()){
                    return 0;
                }
                if (nums.get(i)!=0){
                    break;
                }
            }
            subSequence = new sequence();
            for (int i = 1; i < nums.size(); i++) {
                subSequence.add(nums.get(i)-nums.get(i-1));
            }
            return nums.getFirst()-subSequence.extrapolate();
        }
    }
}

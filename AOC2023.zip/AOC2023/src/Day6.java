import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Day6 {

    public void start(){
        Scanner s = new Scanner(System.in);
        long time = 0;
        s.next();
        while(s.hasNextInt()){
            int z = s.nextInt();
            time*=10;
            if (z>9){
                time*=10;
            }
            if (z>99){
                time*=10;
            }
            if (z>999){
                time*=10;
            }
            if (z>9999){
                time*=10;
            }
            time += z;
        }
        long dist = 0;
        s.next();
        while (s.hasNextInt()){
            int z = s.nextInt();
            dist*=10;
            if (z>9){
                dist*=10;
            }
            if (z>99){
                dist*=10;
            }
            if (z>999){
                dist*=10;
            }
            if (z>9999){
                dist*=10;
            }
            dist += z;
        }
        long minRange = 0;
        long maxRange = time;
        while (maxRange - minRange > 1){
            long mid = (maxRange-minRange)/2+minRange;
            if (num(time,mid)>dist){
                maxRange = mid;
            }
            else if (num(time,mid)<dist){
                minRange = mid;
            }
            else{
                minRange = mid;
                maxRange = mid;
            }
        }
        System.out.println(1+time-(maxRange*2));
    }
    public long num(long time, long push){
        return push * (time-push);
    }
}

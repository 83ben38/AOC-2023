import java.util.Scanner;

public class Day2 {
    public void start(){
        Scanner s = new Scanner(System.in);
        int totalIds = 0;
        while(true){
            String str = s.nextLine();
            str = str.replaceAll(";",",");
            if (str.equals("t")){
                break;
            }
            int[] nums = new int[]{0,0,0};
            str = str.substring(str.indexOf(":") + 2);
            while (!str.isEmpty()) {
                int num;
                if (str.charAt(1) >= '0' && str.charAt(1) <= '9') {
                    num = (str.charAt(0) - '0') * 10 + (str.charAt(1) - '0');
                    str = str.substring(3);
                } else {
                    num = (str.charAt(0) - '0');
                    str = str.substring(2);
                }
                String name = str.contains(",") ? str.substring(0,str.indexOf(",")) : str;
                if (nums[switch (name){case"red" -> 0;case"blue"->1;default -> 2;}] < num){
                    nums[switch (name){case"red" -> 0;case"blue"->1;default -> 2;}] = num;
                }
                str = str.substring(str.indexOf(",")+2);
                if (str.charAt(0) <'0' || str.charAt(0) > '9'){
                    totalIds += nums[0]*nums[1]*nums[2];
                    str = "";
                }
            }

        }
        System.out.println(totalIds);
    }
}

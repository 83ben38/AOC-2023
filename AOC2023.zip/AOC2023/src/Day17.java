import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;
import java.util.Scanner;

public class Day17 {
    /*ArrayList<ArrayList<section>> sections = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            sections.add(new ArrayList<>());
            for (int i = 0; i < str.length(); i++) {
                sections.getLast().add(new section(str.charAt(i)-'0', sections.size()-1,sections.getLast().size()));
            }
        }
        section current = sections.get(0).get(0);
        while (current != sections.getFirst().getLast()){

        }

        System.out.println(sections.getLast().getLast().minHeatLoss.toString());
    }
    public class section{
        public int heatLoss;
        public HashMap<directionsVisited,Integer> minHeatLoss = new HashMap<>();
        int x;
        int y;
        boolean complete;
        public section(int heatLoss, int x, int y){
            this.heatLoss = heatLoss;
            this.x=x;
            this.y=y;
        }
        public void
        public void checkMinHeatLoss(int heatLoss, directionsVisited directions){
            if (heatLoss > (x+y)*15){
                return;
            }
            if (minHeatLoss.getOrDefault(directions,Integer.MAX_VALUE) < heatLoss){
                return;
            }
            minHeatLoss.put(directions,heatLoss);
            for (int i = directions.numDirection+1; i <= 3; i++) {
                directionsVisited d = new directionsVisited(directions.direction,i);
                if (minHeatLoss.getOrDefault(directions,Integer.MAX_VALUE) > heatLoss){
                    minHeatLoss.put(d,heatLoss);
                }
            }
            if (x != 0){
                if ((directions.direction != 0 || directions.numDirection != 3)&& directions.direction!=1){
                    section s =sections.get(x-1).get(y);
                    directionsVisited d;
                    if (directions.direction == 0){
                        d = new directionsVisited(0,directions.numDirection+1);
                    }
                    else{
                        d = new directionsVisited(0,1);
                    }
                    s.checkMinHeatLoss(heatLoss + s.heatLoss,d);
                }
            }
            if (x != sections.size()-1){
                if ((directions.direction != 1 || directions.numDirection != 3)&& directions.direction!=0){
                    section s =sections.get(x+1).get(y);
                    directionsVisited d;
                    if (directions.direction == 1){
                        d = new directionsVisited(1,directions.numDirection+1);
                    }
                    else{
                        d = new directionsVisited(1,1);
                    }
                    s.checkMinHeatLoss(heatLoss + s.heatLoss,d);
                }
            }
            if (y != 0){
                if ((directions.direction != 2 || directions.numDirection != 3)&& directions.direction!=3){
                    section s =sections.get(x).get(y-1);
                    directionsVisited d;
                    if (directions.direction == 2){
                        d = new directionsVisited(2,directions.numDirection+1);
                    }
                    else{
                        d = new directionsVisited(2,1);
                    }
                    s.checkMinHeatLoss(heatLoss + s.heatLoss,d);
                }
            }
            if (y != sections.get(0).size()-1){
                if ((directions.direction != 3 || directions.numDirection != 3)&& directions.direction!=2){
                    section s =sections.get(x).get(y+1);
                    directionsVisited d;
                    if (directions.direction == 3){
                        d = new directionsVisited(3,directions.numDirection+1);
                    }
                    else{
                        d = new directionsVisited(3,1);
                    }
                    s.checkMinHeatLoss(heatLoss + s.heatLoss,d);
                }
            }
        }
    }
    public class directionsVisited{
        int direction;
        int numDirection;

        @Override
        public int hashCode() {
            return direction + numDirection*4;
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof directionsVisited)) return false;
            return direction == ((directionsVisited) obj).direction && numDirection == ((directionsVisited) obj).numDirection;
        }
        public directionsVisited(int direction,int numDirection){
            this.direction = direction;
            this.numDirection = numDirection;
        }
    }*/
    ArrayList<ArrayList<node>> nodes = new ArrayList<>();
    ArrayList<node> nonComplete = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            nodes.add(new ArrayList<>());
            for (int i = 0; i < str.length(); i++) {
                nodes.getLast().add(new node());
                node n = nodes.getLast().getLast();
                n.heatLoss = str.charAt(i) - '0';
                if (nodes.size() > 1){
                    n.north = nodes.get(nodes.size()-2).get(nodes.getLast().size()-1);
                    n.north.south = n;
                }
                if (nodes.getLast().size() > 1){
                    n.west= nodes.getLast().get(nodes.getLast().size()-2);
                    n.west.east = n;
                }
            }
        }
        node current = nodes.getFirst().getFirst();
        for (int i = 0; i < 4; i++) {

                current.minHeatLoss.put(new directionsVisited(i,0),0);

        }

        node end = nodes.getLast().getLast();
        for (ArrayList<node> no: nodes) {
            nonComplete.addAll(no);
        }
        while (!end.complete){
            current.complete = true;
            if(current.north != null){
                int minOverall = Integer.MAX_VALUE;
                for (directionsVisited d: current.minHeatLoss.keySet()) {
                    if (d.direction == 1){
                        continue;
                    }
                    if (d.direction ==0){
                        directionsVisited r = new directionsVisited(0,d.numDirection+1);
                        if (r.numDirection > 10){
                            continue;
                        }
                        if (current.north.minHeatLoss.getOrDefault(r,Integer.MAX_VALUE) > current.minHeatLoss.get(d)+current.north.heatLoss){
                            current.north.minHeatLoss.put(r,current.minHeatLoss.get(d)+current.north.heatLoss);
                            current.north.complete = false;
                        }
                    }
                    else if (d.numDirection > 3){
                        if (current.minHeatLoss.get(d) < minOverall){
                            minOverall = current.minHeatLoss.get(d);
                        }
                    }
                }
                if (minOverall != Integer.MAX_VALUE) {
                    directionsVisited r = new directionsVisited(0, 1);
                    if (current.north.minHeatLoss.getOrDefault(r, Integer.MAX_VALUE) > minOverall + current.north.heatLoss) {
                        current.north.minHeatLoss.put(r, minOverall + current.north.heatLoss);
                        current.north.complete = false;
                    }
                }
            }
            if(current.south != null){
                int minOverall = Integer.MAX_VALUE;
                for (directionsVisited d: current.minHeatLoss.keySet()) {
                    if (d.direction == 0){
                        continue;
                    }
                    if (d.direction ==1){
                        directionsVisited r = new directionsVisited(1,d.numDirection+1);
                        if (r.numDirection > 10){
                            continue;
                        }
                        if (current.south.minHeatLoss.getOrDefault(r,Integer.MAX_VALUE) > current.minHeatLoss.get(d)+current.south.heatLoss){
                            current.south.minHeatLoss.put(r,current.minHeatLoss.get(d)+current.south.heatLoss);
                            current.south.complete = false;
                        }
                    }
                    else if (d.numDirection > 3){
                        if (current.minHeatLoss.get(d) < minOverall){
                            minOverall = current.minHeatLoss.get(d);
                        }
                    }
                }
                if (minOverall != Integer.MAX_VALUE) {
                    directionsVisited r = new directionsVisited(1, 1);
                    if (current.south.minHeatLoss.getOrDefault(r, Integer.MAX_VALUE) > minOverall + current.south.heatLoss) {
                        current.south.minHeatLoss.put(r, minOverall + current.south.heatLoss);
                        current.south.complete = false;
                    }
                }
            }
            if(current.east != null){
                int minOverall = Integer.MAX_VALUE;
                for (directionsVisited d: current.minHeatLoss.keySet()) {
                    if (d.direction == 3){
                        continue;
                    }
                    if (d.direction ==2){
                        directionsVisited r = new directionsVisited(2,d.numDirection+1);
                        if (r.numDirection > 10){
                            continue;
                        }
                        if (current.east.minHeatLoss.getOrDefault(r,Integer.MAX_VALUE) > current.minHeatLoss.get(d)+current.east.heatLoss){
                            current.east.minHeatLoss.put(r,current.minHeatLoss.get(d)+current.east.heatLoss);
                            current.east.complete = false;
                        }
                    }
                    else if (d.numDirection > 3){
                        if (current.minHeatLoss.get(d) < minOverall){
                            minOverall = current.minHeatLoss.get(d);
                        }
                    }
                }
                if (minOverall != Integer.MAX_VALUE) {
                    directionsVisited r = new directionsVisited(2, 1);
                    if (current.east.minHeatLoss.getOrDefault(r, Integer.MAX_VALUE) > minOverall + current.east.heatLoss) {
                        current.east.minHeatLoss.put(r, minOverall + current.east.heatLoss);
                        current.east.complete = false;
                    }
                }
            }
            if(current.west != null){
                int minOverall = Integer.MAX_VALUE;
                for (directionsVisited d: current.minHeatLoss.keySet()) {
                    if (d.direction == 2){
                        continue;
                    }
                    if (d.direction ==3){
                        directionsVisited r = new directionsVisited(3,d.numDirection+1);
                        if (r.numDirection > 10){
                            continue;
                        }
                        if (current.west.minHeatLoss.getOrDefault(r,Integer.MAX_VALUE) > current.minHeatLoss.get(d)+current.west.heatLoss){
                            current.west.minHeatLoss.put(r,current.minHeatLoss.get(d)+current.west.heatLoss);
                            current.west.complete = false;
                        }
                    }
                    else if (d.numDirection > 3){
                        if (current.minHeatLoss.get(d) < minOverall){
                            minOverall = current.minHeatLoss.get(d);
                        }
                    }
                }
                if (minOverall != Integer.MAX_VALUE) {
                    directionsVisited r = new directionsVisited(3, 1);
                    if (current.west.minHeatLoss.getOrDefault(r, Integer.MAX_VALUE) > minOverall + current.west.heatLoss) {
                        current.west.minHeatLoss.put(r, minOverall + current.west.heatLoss);
                        current.west.complete = false;
                    }
                }
            }

            int min = Integer.MAX_VALUE;
            for (node n: nonComplete) {
                if (!n.complete) {
                    int min2 = Integer.MAX_VALUE;
                    for (Integer i : n.minHeatLoss.values()) {
                        if (i < min2) {
                            min2 = i;
                        }
                    }
                    if (min2 < min) {
                        current = n;
                        min = min2;
                    }
                }
            }
        }
        int min2 = Integer.MAX_VALUE;
        for (directionsVisited d: end.minHeatLoss.keySet()) {
            if (d.numDirection > 3){
                if (end.minHeatLoss.get(d) < min2){
                    min2 = end.minHeatLoss.get(d);
                }
            }
        }
        System.out.println(min2);
    }
    public class node{
        node north;
        node south;
        node east;
        node west;
        int heatLoss;
        HashMap<directionsVisited,Integer> minHeatLoss = new HashMap<>();
        boolean complete;
    }
    public class directionsVisited {
        int direction;
        int numDirection;

        @Override
        public int hashCode() {
            return direction + numDirection * 4;
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof directionsVisited)) return false;
            return direction == ((directionsVisited) obj).direction && numDirection == ((directionsVisited) obj).numDirection;
        }

        public directionsVisited(int direction, int numDirection) {
            this.direction = direction;
            this.numDirection = numDirection;
        }
    }
}

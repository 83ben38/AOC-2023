import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Day18 {
    ArrayList<instruction> instructions = new ArrayList<>();
    ArrayList<long[]> coords = new ArrayList<>();
    /*ArrayList<ArrayList<spot>> trench = new ArrayList<>();
    static ArrayList<spot> check = new ArrayList<>();
    static ArrayList<int[]> checkPos = new ArrayList<>();*/
    public void start(){
        Scanner s = new Scanner(System.in);
        while(true){
            String str = s.next();
            if (str.equals("t")){
                break;
            }
            instruction i = new instruction();
            s.nextInt();
            str = s.next();
            str = str.substring(2,str.length()-1);
            i.direction = switch (str.charAt(str.length()-1)){
                case '0' ->'R';
                case '1' -> 'D';
                case '2' -> 'L';
                default -> 'U';
            };
            i.num = Long.parseLong(str.substring(0,str.length()-1),16);
            instructions.add(i);
        }
        coords.add(new long[]{0, 0});
        for (instruction i: instructions) {
            if (i.direction == 'R'){
                coords.add(new long[]{coords.getLast()[0]+i.num,coords.getLast()[1]});
            }
            if (i.direction == 'L'){
                coords.add(new long[]{coords.getLast()[0]-i.num,coords.getLast()[1]});
            }
            if (i.direction == 'U'){
                coords.add(new long[]{coords.getLast()[0],coords.getLast()[1]+i.num});
            }
            if (i.direction == 'D'){
                coords.add(new long[]{coords.getLast()[0],coords.getLast()[1]-i.num});
            }
        }
        coords.add(new long[]{0,0});
        long total = 0;
        for (int i = 0; i < coords.size()-1; i++) {
            total += coords.get(i)[0]*coords.get(i+1)[1];
        }
        for (int i = 0; i < coords.size()-1; i++) {
            total -= coords.get(i)[1]*coords.get(i+1)[0];
        }
        for (int i = 0; i < instructions.size(); i++) {
            total -= instructions.get(i).num;
        }
        total -= 2;
        System.out.println(total/2);

        /*addXPlus();
        addYPlus();
        int[] currentPos = new int[]{0,0};
        for (instruction i: instructions) {
            for (int j = 0; j < i.num; j++) {
                currentPos[switch (i.direction){
                    case 'R','L' ->0;
                    default -> 1;
                }] += switch (i.direction){
                    case 'R','D' -> 1;
                    default -> -1;
                };
                if (currentPos[0] < 0){
                    addXMinus();
                    currentPos[0]++;
                }
                if (currentPos[1] < 0){
                    addYMinus();
                    currentPos[1]++;
                }
                if (currentPos[0] == trench.size()){
                    addXPlus();
                }
                if (currentPos[1] == trench.getFirst().size()){
                    addYPlus();
                }
                trench.get(currentPos[0]).set(currentPos[1],new spot(true));
            }
        }
        for (int i = 0; i < trench.size(); i++) {
            trench.get(i).getFirst().checkEdged(i,0);
            trench.get(i).getLast().checkEdged(i,trench.get(i).size()-1);
        }
        for (int i = 0; i < trench.get(0).size(); i++) {
            trench.getFirst().get(i).checkEdged(0,i);
            trench.getLast().get(i).checkEdged(trench.size()-1, i);
        }
        while (!check.isEmpty()){
            ArrayList<spot> oldCheck = check;
            ArrayList<int[]> oldCheckPos = checkPos;
            check = new ArrayList<>();
            checkPos = new ArrayList<>();
            for (int i = 0; i < oldCheck.size(); i++) {
                oldCheck.get(i).checkEdged(oldCheckPos.get(i)[0],oldCheckPos.get(i)[1]);
            }
        }
        int total = 0;
        for (ArrayList<spot> spots: trench) {
            for (spot sp: spots) {
                if (!sp.edged){
                    total++;
                }
            }
        }
        System.out.println(total);*/
    }
   /* public class spot{
        boolean filled;
        boolean edged = false;
        public spot(boolean filled){
            this.filled = filled;
        }
        public void checkEdged(int x, int y){
            if (edged || filled){
                return;
            }
            edged = true;
            if (x != 0){
                check.add(trench.get(x-1).get(y));
                checkPos.add(new int[]{x-1,y});
            }
            if (x != trench.size()-1){
                check.add(trench.get(x+1).get(y));
                checkPos.add(new int[]{x+1,y});
            }
            if (y != 0){
                check.add(trench.get(x).get(y-1));
                checkPos.add(new int[]{x,y-1});
            }
            if (y != trench.getFirst().size()-1){
                check.add(trench.get(x).get(y+1));
                checkPos.add(new int[]{x,y+1});
            }
        }
    }
    public void addXPlus(){
        trench.add(new ArrayList<>());
        for (int i = 0; i < trench.get(0).size(); i++) {
            trench.getLast().add(new spot(false));
        }
    }
    public void addXMinus(){
        trench.add(0,new ArrayList<>());
        for (int i = 0; i < trench.get(1).size(); i++) {
            trench.getFirst().add(new spot(false));
        }
    }
    public void addYPlus(){
        for (ArrayList<spot> booleans : trench) {
            booleans.add(new spot(false));
        }
    }
    public void addYMinus(){
        for (ArrayList<spot> booleans : trench) {
            booleans.add(0, new spot(false));
        }
    }*/
    public class instruction{
        char direction;
        long num;
    }
}

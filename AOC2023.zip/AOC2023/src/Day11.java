import java.util.ArrayList;
import java.util.Scanner;

public class Day11 {
    ArrayList<ArrayList<Boolean>> map = new ArrayList<>();
    ArrayList<Integer> x = new ArrayList<>();
    ArrayList<Integer> y = new ArrayList<>();
    ArrayList<coord> galx = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while (true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            map.add(new ArrayList<>());
            for (int i = 0; i < str.length(); i++) {
                map.getLast().add(str.charAt(i)=='#');
            }
        }
        x.add(0);
        for (int i = 1; i < map.size(); i++) {
            boolean duplicate = true;
            for (int j = 0; j < map.get(i).size(); j++) {
                if (map.get(i).get(j)){
                    duplicate = false;
                    break;
                }
            }
            if (duplicate){
                x.add(x.getLast()+1000000);
            }
            else{
                x.add(x.getLast()+1);
            }
        }
        y.add(0);
        for (int i = 1; i < map.get(0).size(); i++) {
            boolean duplicate = true;
            for (int j = 0; j < map.size(); j++) {
                if (map.get(j).get(i)){
                    duplicate = false;
                    break;
                }
            }
            if (duplicate){
                y.add(y.getLast()+1000000);
            }
            else{
                y.add(y.getLast()+1);
            }
        }
        for (int i = 0; i < map.size(); i++) {
            for (int j = 0; j < map.get(i).size(); j++) {
                if (map.get(i).get(j)){
                    galx.add(new coord(x.get(i),y.get(j)));
                }
            }
        }
        long total = 0;
        for (int i = 0; i < galx.size(); i++) {
            for (int j = i+1; j < galx.size(); j++) {
                total += galx.get(i).distance(galx.get(j));
            }
        }
        System.out.println(total);
    }
    public class coord {
        int x;
        int y;
        public coord(int x, int y){
            this.x=x;
            this.y=y;
        }
        int distance(coord c){
            return Math.abs(x-c.x)+Math.abs(y-c.y);
        }
    }
}

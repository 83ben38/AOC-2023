import java.util.ArrayList;
import java.util.Scanner;

public class Day15 {
    ArrayList<ArrayList<lens>> lenses = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        str = str.replaceAll(","," ");
        s = new Scanner(str);
        int total = 0;
        for (int i = 0; i < 256; i++) {
            lenses.add(new ArrayList<>());
        }
        while(s.hasNext()){
            String com = s.next();
            if (com.contains("=")){
                int z = com.charAt(com.length()-1) - '0';
                String name = com.substring(0,com.length()-2);
                ArrayList<lens> hash = lenses.get(value(name));
                lens d = new lens();
                d.value = z;
                d.name = name;
                if (hash.contains(d)){
                    hash.set(hash.indexOf(d),d);
                }
                else{
                    hash.add(d);
                }
            }
            else{
                String name = com.substring(0,com.length()-1);
                ArrayList<lens> hash = lenses.get(value(name));
                lens d = new lens();
                d.name = name;
                hash.remove(d);
            }
        }
        for (int i = 0; i < 256; i++) {
            for (int j = 1; j <= lenses.get(i).size(); j++) {
                total += (i+1)*j*lenses.get(i).get(j-1).value;
            }
        }

        System.out.println(total);
    }
    public int value(String r){
        int z = 0;
        for (int i = 0; i < r.length(); i++) {
            z += r.charAt(i);
            z*=17;
            z%=256;
        }
        return z;
    }
    public class lens{
        String name;
        int value;

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof lens)) return false;
            return name.equals(((lens) obj).name);
        }
    }
}

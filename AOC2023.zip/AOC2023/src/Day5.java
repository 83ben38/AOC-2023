import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Day5 {
    ArrayList<seedRange> seeds = new ArrayList<>();
    ArrayList<map>[] maps = new ArrayList[7];
    public void start(){
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 7; i++) {
            maps[i] = new ArrayList<>();
        }
        int min = 0;
        s.next();
        while(s.hasNextLong()){
            seeds.add(new seedRange(s.nextLong(),s.nextLong()));
        }
        for (int i = 0; i < 7; i++) {
            s.next();
            s.next();
            while(s.hasNextLong()){
                maps[i].add(new map(s.nextLong(),s.nextLong(),s.nextLong()));
            }
        }
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < seeds.size(); j++) {
                for (int k = 0; k < maps[i].size(); k++) {
                    seedRange[] f = maps[i].get(k).getMap(seeds.get(j));
                    if (f.length > 0){
                        if (f.length == 1) {
                            seeds.set(j, f[0]);
                            break;
                        }
                        else if (f.length == 2){
                            seeds.add(j+1,f[1]);
                            seeds.set(j, f[0]);
                            break;
                        }
                        else if (f.length == 3){
                            seeds.add(j+1,f[1]);
                            seeds.add(j+2,f[2]);
                            seeds.set(j, f[0]);
                            break;
                        }
                    }
                }
            }
        }
        seeds.sort(Comparator.comparingLong(o -> o.min));
        System.out.println(seeds.get(0).min);
    }
    public class map{
        long destStart;
        long srcStart;
        long length;
        public map(long destStart, long srcStart, long length){
            this.destStart = destStart;
            this.srcStart = srcStart;
            this.length = length;
        }
        public seedRange[] getMap(seedRange z){
            if (z.min >= srcStart + length || z.min + z.length <= srcStart){
                return new seedRange[0];
            }
            if (z.min >= srcStart && z.min + z.length <= srcStart + length){
                return new seedRange[]{new seedRange(z.min-srcStart+destStart,z.length)};
            }
            if (z.min >= srcStart) {
                return new seedRange[]{new seedRange(z.min-srcStart+destStart,srcStart+length-z.min),new seedRange(srcStart+length,z.length+z.min-srcStart-length)};
            }
            if (z.min + z.length <= srcStart + length){
                return new seedRange[]{new seedRange(destStart,z.length+z.min-srcStart),new seedRange(z.min,srcStart-z.min)};
            }
            return new seedRange[]{new seedRange(destStart,length),new seedRange(z.min,srcStart-z.min),new seedRange(srcStart+length,z.min+z.length-srcStart-length)};
        }
    }
    public class seedRange{
        long min;
        long length;
        public seedRange(long min, long plus){
            this.min = min;
            this.length = plus;
        }
    }

}

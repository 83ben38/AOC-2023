import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Day14 {
    ArrayList<ArrayList<ArrayList<Integer>>> cycles = new ArrayList<>();
    ArrayList<ArrayList<Integer>> rocks = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        while(true){
            String str = s.nextLine();
            if (str.equals("t")){
                break;
            }
            ArrayList<Integer> row = new ArrayList<>();
            rocks.add(row);

            for (int i = 0; i < str.length(); i++) {
                row.add(str.charAt(i)=='.' ? 0 : str.charAt(i) == '#' ? 1 : 2);
            }
        }
        while (!cycles.contains(rocks)) {
            cycles.add(new ArrayList<>());
            for (ArrayList<Integer> rock : rocks) {
                cycles.getLast().add(new ArrayList<>(rock));
            }
            for (int i = 0; i < rocks.size(); i++) {
                for (int j = 0; j < rocks.get(i).size(); j++) {
                    if (rocks.get(i).get(j) == 2) {
                        for (int k = i; k > 0; k--) {
                            if (rocks.get(k - 1).get(j) == 0) {
                                rocks.get(k - 1).set(j, 2);
                                rocks.get(k).set(j, 0);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < rocks.get(0).size(); i++) {
                for (int j = 0; j < rocks.size(); j++) {
                    if (rocks.get(j).get(i) == 2) {
                        for (int k = i; k > 0; k--) {
                            if (rocks.get(j).get(k - 1) == 0) {
                                rocks.get(j).set(k - 1, 2);
                                rocks.get(j).set(k, 0);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            for (int i = rocks.size() - 1; i >= 0; i--) {
                for (int j = 0; j < rocks.get(i).size(); j++) {
                    if (rocks.get(i).get(j) == 2) {
                        for (int k = i; k < rocks.size() - 1; k++) {
                            if (rocks.get(k + 1).get(j) == 0) {
                                rocks.get(k + 1).set(j, 2);
                                rocks.get(k).set(j, 0);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
            for (int i = rocks.get(0).size() - 1; i >= 0; i--) {
                for (int j = 0; j < rocks.size(); j++) {
                    if (rocks.get(j).get(i) == 2) {
                        for (int k = i; k < rocks.get(0).size() - 1; k++) {
                            if (rocks.get(j).get(k + 1) == 0) {
                                rocks.get(j).set(k + 1, 2);
                                rocks.get(j).set(k, 0);
                            } else {
                                break;
                            }
                        }
                    }
                }
            }

        }
        int cycle = cycles.size()-cycles.indexOf(rocks);
        long z = 1000000000 - cycles.indexOf(rocks);

        z %= cycle;
        rocks = cycles.get((int) z+cycles.indexOf(rocks));int total = 0;
        for (int i = 0; i < rocks.size(); i++) {
            for (int j = 0; j < rocks.get(i).size(); j++) {
                if (rocks.get(i).get(j)==2){
                    total += rocks.size()-i;
                }
            }
        }
        System.out.println(total);
    }

}

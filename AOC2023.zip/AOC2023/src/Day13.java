import java.util.ArrayList;
import java.util.Scanner;

public class Day13 {
    ArrayList<ArrayList<ArrayList<Boolean>>> maps = new ArrayList<>();
    public void start(){
        Scanner s = new Scanner(System.in);
        int total = 0;
        while(true){
            String str = s.nextLine();
            if(str.equals("t")){
                break;
            }
            ArrayList<ArrayList<Boolean>> c = new ArrayList<>();
            maps.add(c);
            while (!str.isEmpty()){
                ArrayList<Boolean> b = new ArrayList<>();
                c.add(b);
                for (int i = 0; i < str.length(); i++) {
                    b.add(str.charAt(i)=='#');
                }
                str = s.nextLine();
            }
        }
        for (ArrayList<ArrayList<Boolean>> map: maps) {
            boolean done = false;
            for (int i = 0; i < map.size()-1; i++) {
                if (checkForSymmetryX(i,map)){
                    total += (i+1)*100;
                    done = true;
                    break;
                }
            }
            if (!done){
                for (int i = 0; i < map.get(0).size()-1; i++) {
                    if (checkForSymmetryY(i,map)){
                        total += (i+1);
                        break;
                    }
                }
            }
        }
        System.out.println(total);
    }
    public boolean checkForSymmetryX(int line, ArrayList<ArrayList<Boolean>> map){
        int mistakes =0;
        for (int i = 0; line-i >= 0 && line+i+1<map.size(); i++) {
            for (int j = 0; j < map.get(line+i+1).size(); j++) {
                if (map.get(line+i+1).get(j)!=map.get(line-i).get(j)){
                    mistakes++;
                }
            }
        }
        return mistakes==1;
    }
    public boolean checkForSymmetryY(int line, ArrayList<ArrayList<Boolean>> map){
        int mistakes = 0;
        for (int i = 0; line-i >= 0 && line+i+1<map.get(0).size(); i++) {

            for (int j = 0; j < map.size(); j++) {
                if (map.get(j).get(line+i+1)!=map.get(j).get(line-i)){
                    mistakes++;
                }
            }

        }
        return mistakes==1;
    }
}
